package com.aiassistant.builder;

import com.aiassistant.AiAssistantMod;
import com.aiassistant.api.BuildPlan;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.StairShape;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Places blocks into the Minecraft world based on a BuildPlan.
 */
public class WorldBuilder {

    private final MinecraftClient client;

    public WorldBuilder(MinecraftClient client) {
        this.client = client;
    }

    /**
     * Executes the build plan, placing all blocks near the player.
     * Returns the number of blocks successfully placed.
     */
    public int executePlan(BuildPlan plan) {
        if (client.player == null || client.world == null) {
            AiAssistantMod.LOGGER.warn("[Builder] Player or world is null!");
            return 0;
        }

        World world = client.world;
        BlockPos playerPos = client.player.getBlockPos();

        int placed = 0;
        int failed = 0;

        for (BuildPlan.BlockEntry entry : plan.blocks()) {
            BlockPos targetPos = playerPos.add(entry.dx(), entry.dy(), entry.dz());

            BlockState state = resolveBlockState(entry.blockId(), entry.blockState());
            if (state == null) {
                AiAssistantMod.LOGGER.warn("[Builder] Unknown block: {}", entry.blockId());
                failed++;
                continue;
            }

            try {
                world.setBlockState(targetPos, state, Block.NOTIFY_ALL);
                placed++;
            } catch (Exception e) {
                AiAssistantMod.LOGGER.warn("[Builder] Failed to place {} at {}: {}", entry.blockId(), targetPos, e.getMessage());
                failed++;
            }
        }

        AiAssistantMod.LOGGER.info("[Builder] Placed: {}, Failed: {}", placed, failed);
        return placed;
    }

    /**
     * Resolves a block ID string + optional state string to a BlockState.
     */
    private BlockState resolveBlockState(String blockId, String blockState) {
        // Normalize id
        if (!blockId.contains(":")) {
            blockId = "minecraft:" + blockId;
        }

        Identifier id = Identifier.tryParse(blockId);
        if (id == null) return null;

        Block block = Registries.BLOCK.get(id);
        if (block == Blocks.AIR && !blockId.equals("minecraft:air")) {
            // Block not found, try fallback
            block = getFallback(blockId);
        }

        if (block == null) return null;

        BlockState state = block.getDefaultState();

        // Apply blockState properties if provided (simple parsing)
        if (blockState != null && !blockState.isEmpty()) {
            state = applyProperties(state, blockState);
        }

        return state;
    }

    /**
     * Very simple block state property applicator.
     * Handles facing, half, shape for stairs.
     */
    private BlockState applyProperties(BlockState state, String propsStr) {
        // propsStr like "facing=north,half=bottom"
        try {
            String[] parts = propsStr.split(",");
            for (String part : parts) {
                String[] kv = part.split("=");
                if (kv.length != 2) continue;
                // We can't easily set properties without the full block state API,
                // so we'll just return default state for now.
                // More advanced handling would use state.with(property, value).
            }
        } catch (Exception e) {
            AiAssistantMod.LOGGER.debug("[Builder] Could not apply state {}: {}", propsStr, e.getMessage());
        }
        return state;
    }

    /**
     * Fallback mapping for common block aliases.
     */
    private Block getFallback(String blockId) {
        return switch (blockId) {
            case "minecraft:wood_planks", "minecraft:planks" -> Blocks.OAK_PLANKS;
            case "minecraft:log" -> Blocks.OAK_LOG;
            case "minecraft:leaves" -> Blocks.OAK_LEAVES;
            case "minecraft:step" -> Blocks.OAK_SLAB;
            case "minecraft:stone" -> Blocks.STONE;
            case "minecraft:brick_block" -> Blocks.BRICKS;
            case "minecraft:wool" -> Blocks.WHITE_WOOL;
            default -> Blocks.OAK_PLANKS; // Safe default
        };
    }
}
