package com.aiassistant.client.gui;

import com.aiassistant.AiAssistantMod;
import com.aiassistant.api.AnthropicClient;
import com.aiassistant.api.BuildPlan;
import com.aiassistant.builder.WorldBuilder;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class AiSidebarScreen extends Screen {

    private static final int SIDEBAR_WIDTH = 320;
    private static final int PADDING = 10;
    private static final int INPUT_HEIGHT = 22;
    private static final int BUTTON_HEIGHT = 20;

    private final Screen parent;

    private TextFieldWidget inputField;
    private ButtonWidget sendButton;
    private ButtonWidget buildButton;
    private ButtonWidget cancelButton;

    // Chat history: list of [type, message]  type: "user", "ai", "system"
    private final List<ChatMessage> messages = new ArrayList<>();

    private BuildPlan pendingPlan = null;
    private boolean isLoading = false;
    private String loadingText = "Думаю...";
    private int loadingTick = 0;

    // Config - user sets this once
    // API key loaded from config

    public AiSidebarScreen(Screen parent) {
        super(Text.literal("AI Будівельник"));
        this.parent = parent;
        messages.add(new ChatMessage("system", "👋 Привіт! Напиши що побудувати, наприклад: \"побудуй дім\" або \"зроби вежу 5x5x10\""));
    }

    @Override
    protected void init() {
        int panelX = 0;
        int panelY = 0;
        int panelH = this.height;
        int bottomY = panelH - PADDING - INPUT_HEIGHT - PADDING - BUTTON_HEIGHT - PADDING;

        // Input field at bottom of sidebar
        inputField = new TextFieldWidget(
                this.textRenderer,
                panelX + PADDING,
                bottomY + PADDING,
                SIDEBAR_WIDTH - PADDING * 2 - 55,
                INPUT_HEIGHT,
                Text.literal("Повідомлення")
        );
        inputField.setMaxLength(500);
        inputField.setPlaceholder(Text.literal("Напиши команду...").formatted(Formatting.GRAY));
        this.addSelectableChild(inputField);
        this.setInitialFocus(inputField);

        // Send button
        sendButton = ButtonWidget.builder(Text.literal("➤"), button -> sendMessage())
                .dimensions(panelX + SIDEBAR_WIDTH - PADDING - 50, bottomY + PADDING, 50, INPUT_HEIGHT)
                .build();
        this.addDrawableChild(sendButton);

        // Build / Confirm button (only visible when plan is pending)
        buildButton = ButtonWidget.builder(
                Text.literal("✅ Будувати! (Enter)"),
                button -> confirmBuild()
        ).dimensions(panelX + PADDING, bottomY + PADDING * 2 + INPUT_HEIGHT, (SIDEBAR_WIDTH - PADDING * 3) / 2, BUTTON_HEIGHT)
                .build();
        buildButton.visible = false;
        this.addDrawableChild(buildButton);

        cancelButton = ButtonWidget.builder(
                Text.literal("❌ Скасувати"),
                button -> cancelBuild()
        ).dimensions(panelX + PADDING + (SIDEBAR_WIDTH - PADDING * 3) / 2 + PADDING,
                bottomY + PADDING * 2 + INPUT_HEIGHT,
                (SIDEBAR_WIDTH - PADDING * 3) / 2, BUTTON_HEIGHT)
                .build();
        cancelButton.visible = false;
        this.addDrawableChild(cancelButton);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Draw semi-transparent sidebar background
        context.fill(0, 0, SIDEBAR_WIDTH, this.height, 0xDD111827);

        // Header
        context.fill(0, 0, SIDEBAR_WIDTH, 28, 0xFF1E3A5F);
        context.drawTextWithShadow(textRenderer,
                Text.literal("🤖 AI Будівельник").formatted(Formatting.AQUA),
                PADDING, 9, 0xFFFFFF);

        // Close hint
        context.drawTextWithShadow(textRenderer,
                Text.literal("[J] закрити").formatted(Formatting.DARK_GRAY),
                SIDEBAR_WIDTH - 65, 10, 0xFFFFFF);

        // Draw separator
        context.fill(0, 28, SIDEBAR_WIDTH, 29, 0xFF2563EB);

        // Draw chat messages
        renderMessages(context);

        // Draw loading indicator
        if (isLoading) {
            loadingTick++;
            String dots = ".".repeat((loadingTick / 10) % 4);
            context.drawTextWithShadow(textRenderer,
                    Text.literal(loadingText + dots).formatted(Formatting.YELLOW),
                    PADDING, this.height - 80, 0xFFFFFF);
        }

        // Draw pending plan indicator
        if (pendingPlan != null && !isLoading) {
            context.fill(0, this.height - 75, SIDEBAR_WIDTH, this.height - 52, 0xFF064E3B);
            context.drawTextWithShadow(textRenderer,
                    Text.literal("📦 План готовий! Натисни Enter або кнопку").formatted(Formatting.GREEN),
                    PADDING, this.height - 70, 0xFFFFFF);
            context.drawTextWithShadow(textRenderer,
                    Text.literal("Блоків: " + pendingPlan.blockCount() + " | Розмір: " + pendingPlan.size()).formatted(Formatting.GRAY),
                    PADDING, this.height - 60, 0xFFFFFF);
        }

        // Draw input area background
        context.fill(0, this.height - 52, SIDEBAR_WIDTH, this.height, 0xFF1E293B);
        context.fill(0, this.height - 53, SIDEBAR_WIDTH, this.height - 52, 0xFF334155);

        // Draw widgets
        super.render(context, mouseX, mouseY, delta);
    }

    private void renderMessages(DrawContext context) {
        int chatTop = 32;
        int chatBottom = this.height - 58;
        if (pendingPlan != null) chatBottom -= 26;

        // Enable scissor to clip messages within chat area
        context.enableScissor(0, chatTop, SIDEBAR_WIDTH, chatBottom);

        int y = chatBottom - 12;
        int maxWidth = SIDEBAR_WIDTH - PADDING * 2 - 4;

        // Render from bottom to top
        for (int i = messages.size() - 1; i >= 0 && y > chatTop; i--) {
            ChatMessage msg = messages.get(i);
            List<String> lines = wrapText(msg.text, maxWidth);

            int lineColor = switch (msg.type) {
                case "user" -> 0xFFDBEAFE;
                case "ai" -> 0xFFD1FAE5;
                case "system" -> 0xFFE5E7EB;
                case "error" -> 0xFFFECACA;
                default -> 0xFFFFFFFF;
            };

            String prefix = switch (msg.type) {
                case "user" -> "§9Ти: §r";
                case "ai" -> "§2AI: §r";
                case "system" -> "§7";
                case "error" -> "§c⚠ ";
                default -> "";
            };

            // Draw lines in reverse
            for (int l = lines.size() - 1; l >= 0 && y > chatTop; l--) {
                String line = (l == 0 ? prefix : "   ") + lines.get(l);
                context.drawTextWithShadow(textRenderer, line, PADDING + 2, y, lineColor);
                y -= 12;
            }
            y -= 3; // gap between messages
        }

        context.disableScissor();
    }

    private List<String> wrapText(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        String[] words = text.split(" ");
        StringBuilder current = new StringBuilder();
        for (String word : words) {
            String test = current.isEmpty() ? word : current + " " + word;
            if (textRenderer.getWidth(test) > maxWidth) {
                if (!current.isEmpty()) {
                    lines.add(current.toString());
                    current = new StringBuilder(word);
                } else {
                    lines.add(word);
                }
            } else {
                if (!current.isEmpty()) current.append(" ");
                current.append(word);
            }
        }
        if (!current.isEmpty()) lines.add(current.toString());
        return lines.isEmpty() ? List.of("") : lines;
    }

    private void sendMessage() {
        String text = inputField.getText().trim();
        if (text.isEmpty() || isLoading) return;

        inputField.setText("");
        messages.add(new ChatMessage("user", text));
        pendingPlan = null;
        buildButton.visible = false;
        cancelButton.visible = false;

        isLoading = true;
        loadingText = "Думаю";

        // Check API key
        if (com.aiassistant.AiAssistantConfig.apiKey.isEmpty() || com.aiassistant.AiAssistantConfig.apiKey.equals("YOUR_API_KEY")) {
            messages.add(new ChatMessage("error",
                    "❌ Встанови API ключ Anthropic у файлі config/aiassistant.json"));
            isLoading = false;
            return;
        }

        // Run API call on separate thread
        Thread apiThread = new Thread(() -> {
            try {
                loadingText = "Проектую";
                BuildPlan plan = AnthropicClient.generateBuildPlan(com.aiassistant.AiAssistantConfig.apiKey, text);
                // Back on main thread
                if (this.client != null) {
                    this.client.execute(() -> {
                        isLoading = false;
                        if (plan != null) {
                            pendingPlan = plan;
                            messages.add(new ChatMessage("ai", plan.description()));
                            buildButton.visible = true;
                            cancelButton.visible = true;
                        } else {
                            messages.add(new ChatMessage("error", "Не вдалося отримати план будівництва"));
                        }
                    });
                }
            } catch (Exception e) {
                AiAssistantMod.LOGGER.error("API error", e);
                if (this.client != null) {
                    this.client.execute(() -> {
                        isLoading = false;
                        messages.add(new ChatMessage("error", "Помилка: " + e.getMessage()));
                    });
                }
            }
        }, "AI-Builder-Thread");
        apiThread.setDaemon(true);
        apiThread.start();
    }

    private void confirmBuild() {
        if (pendingPlan == null) return;
        messages.add(new ChatMessage("system", "🏗 Будую " + pendingPlan.name() + "..."));

        BuildPlan planToExecute = pendingPlan;
        pendingPlan = null;
        buildButton.visible = false;
        cancelButton.visible = false;

        // Execute building in game thread
        if (this.client != null && this.client.player != null && this.client.world != null) {
            WorldBuilder builder = new WorldBuilder(this.client);
            int placed = builder.executePlan(planToExecute);
            messages.add(new ChatMessage("ai", "✅ Готово! Розміщено " + placed + " блоків."));
        }
    }

    private void cancelBuild() {
        pendingPlan = null;
        buildButton.visible = false;
        cancelButton.visible = false;
        messages.add(new ChatMessage("system", "Скасовано."));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.close();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            if (pendingPlan != null) {
                confirmBuild();
                return true;
            }
            if (inputField.isFocused() && !inputField.getText().isEmpty()) {
                sendMessage();
                return true;
            }
        }
        // Don't pass J key to game to prevent toggle loop
        if (keyCode == GLFW.GLFW_KEY_J) {
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false; // Game continues to run behind sidebar
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // If click is outside sidebar, close
        if (mouseX > SIDEBAR_WIDTH) {
            this.close();
            return false;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    // Simple message record
    record ChatMessage(String type, String text) {}
}
