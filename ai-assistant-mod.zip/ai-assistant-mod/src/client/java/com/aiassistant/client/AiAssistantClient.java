package com.aiassistant.client;

import com.aiassistant.AiAssistantMod;
import com.aiassistant.client.gui.AiSidebarScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class AiAssistantClient implements ClientModInitializer {

    public static KeyBinding openAiPanelKey;
    public static AiSidebarScreen currentScreen = null;

    @Override
    public void onInitializeClient() {
        // Register J key binding
        openAiPanelKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aiassistant.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_J,
                "category.aiassistant"
        ));

        // Check key press every tick
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openAiPanelKey.wasPressed()) {
                if (client.currentScreen == null) {
                    // Open sidebar overlay (keeps game rendering behind it)
                    client.setScreen(new AiSidebarScreen(client.currentScreen));
                } else if (client.currentScreen instanceof AiSidebarScreen) {
                    client.setScreen(null);
                }
            }
        });

        AiAssistantMod.LOGGER.info("[AI Assistant] Client initialized. Press J to open AI panel.");
    }
}
