package com.aiassistant.api;

import com.aiassistant.AiAssistantMod;
import com.google.gson.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Calls the Anthropic API to generate Minecraft building plans.
 */
public class AnthropicClient {

    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private static final String MODEL = "claude-sonnet-4-6";

    private static final String SYSTEM_PROMPT = """
            Ти — Minecraft будівельний AI. Коли гравець описує що хоче побудувати,
            ти генеруєш JSON план будівництва.
            
            ДУЖЕ ВАЖЛИВО: Відповідай ТІЛЬКИ JSON, без пояснень, без markdown, без ```json.
            
            Структура JSON:
            {
              "name": "Назва споруди",
              "description": "Короткий опис що буде побудовано (1-2 речення)",
              "size": "ШxВxГ",
              "blocks": [
                {"dx": 0, "dy": 0, "dz": 0, "blockId": "minecraft:oak_planks"},
                ...
              ]
            }
            
            Правила:
            - dx/dy/dz — зміщення відносно позиції гравця. dy=0 це рівень гравця (ноги).
            - Починай від позиції гравця, будуй спереду і праворуч (позитивний X та Z).
            - Завжди починай з фундаменту (dy=-1 або dy=0).
            - Використовуй лише ванільні Minecraft блоки (minecraft:xxx).
            - Для будинку: підлога, стіни, дах, двері, вікна.
            - Для вежі: квадратний периметр, сходи всередині.
            - Максимум 500 блоків для невеликих споруд.
            - Дах може бути з minecraft:oak_stairs зі станом facing=north/south/east/west.
            
            Популярні блоки:
            minecraft:oak_planks, minecraft:stone_bricks, minecraft:cobblestone,
            minecraft:oak_log, minecraft:glass, minecraft:oak_door,
            minecraft:oak_stairs, minecraft:stone_brick_stairs,
            minecraft:torch, minecraft:crafting_table, minecraft:bookshelf,
            minecraft:gravel, minecraft:dirt, minecraft:grass_block,
            minecraft:sand, minecraft:sandstone, minecraft:bricks
            """;

    /**
     * Sends user request to Anthropic API and parses the response into a BuildPlan.
     */
    public static BuildPlan generateBuildPlan(String apiKey, String userMessage) throws Exception {
        // Build request JSON
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("model", MODEL);
        requestBody.addProperty("max_tokens", 4096);
        requestBody.addProperty("system", SYSTEM_PROMPT);

        JsonArray messages = new JsonArray();
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", userMessage);
        messages.add(userMsg);
        requestBody.add("messages", messages);

        String jsonBody = new Gson().toJson(requestBody);

        // Make HTTP request
        URL url = new URL(API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", apiKey);
        conn.setRequestProperty("anthropic-version", "2023-06-01");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonBody.getBytes(StandardCharsets.UTF_8));
        }

        int responseCode = conn.getResponseCode();
        InputStream is = responseCode == 200 ? conn.getInputStream() : conn.getErrorStream();

        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
        }

        if (responseCode != 200) {
            AiAssistantMod.LOGGER.error("API error {}: {}", responseCode, response);
            throw new IOException("API помилка " + responseCode + ": " + response.substring(0, Math.min(200, response.length())));
        }

        // Parse Anthropic response
        JsonObject apiResponse = JsonParser.parseString(response.toString()).getAsJsonObject();
        String content = apiResponse
                .getAsJsonArray("content")
                .get(0)
                .getAsJsonObject()
                .get("text")
                .getAsString()
                .trim();

        // Strip potential markdown fences just in case
        if (content.startsWith("```")) {
            content = content.replaceFirst("```json\\s*", "").replaceFirst("```\\s*$", "").trim();
        }

        AiAssistantMod.LOGGER.info("[AI Assistant] Plan received: {}", content.substring(0, Math.min(300, content.length())));

        return parseBuildPlan(content);
    }

    private static BuildPlan parseBuildPlan(String json) {
        JsonObject obj = JsonParser.parseString(json).getAsJsonObject();

        String name = obj.has("name") ? obj.get("name").getAsString() : "Споруда";
        String description = obj.has("description") ? obj.get("description").getAsString() : "";
        String size = obj.has("size") ? obj.get("size").getAsString() : "?";

        JsonArray blocksArray = obj.getAsJsonArray("blocks");
        List<BuildPlan.BlockEntry> blocks = new ArrayList<>();

        for (JsonElement el : blocksArray) {
            JsonObject b = el.getAsJsonObject();
            int dx = b.get("dx").getAsInt();
            int dy = b.get("dy").getAsInt();
            int dz = b.get("dz").getAsInt();
            String blockId = b.get("blockId").getAsString();
            String blockState = b.has("blockState") ? b.get("blockState").getAsString() : null;
            blocks.add(new BuildPlan.BlockEntry(dx, dy, dz, blockId, blockState));
        }

        return new BuildPlan(name, description, size, blocks.size(), blocks);
    }
}
