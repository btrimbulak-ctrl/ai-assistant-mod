package com.aiassistant.api;

import java.util.List;

/**
 * Represents a build plan returned from the AI.
 */
public record BuildPlan(
        String name,
        String description,
        String size,
        int blockCount,
        List<BlockEntry> blocks
) {
    /**
     * A single block placement instruction.
     * dx, dy, dz = offset from player position
     * blockId = Minecraft block ID (e.g. "minecraft:oak_planks")
     */
    public record BlockEntry(int dx, int dy, int dz, String blockId, String blockState) {
        public BlockEntry(int dx, int dy, int dz, String blockId) {
            this(dx, dy, dz, blockId, null);
        }
    }
}
