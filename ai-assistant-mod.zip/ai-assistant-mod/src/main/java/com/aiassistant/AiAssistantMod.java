package com.aiassistant;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AiAssistantMod implements ModInitializer {
    public static final String MOD_ID = "aiassistant";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        AiAssistantConfig.load();
        LOGGER.info("[AI Assistant] Mod initialized! API key set: {}", !AiAssistantConfig.apiKey.isEmpty());
    }
}
