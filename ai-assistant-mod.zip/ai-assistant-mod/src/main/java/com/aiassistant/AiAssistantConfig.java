package com.aiassistant;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class AiAssistantConfig {

    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("aiassistant.json");

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static String apiKey = "";

    public static void load() {
        if (!Files.exists(CONFIG_PATH)) {
            save(); // Create default config
            AiAssistantMod.LOGGER.info("[AI Assistant] Created config at: {}", CONFIG_PATH);
            return;
        }
        try (Reader reader = new FileReader(CONFIG_PATH.toFile())) {
            JsonObject obj = JsonParser.parseReader(reader).getAsJsonObject();
            if (obj.has("apiKey")) {
                apiKey = obj.get("apiKey").getAsString();
            }
        } catch (Exception e) {
            AiAssistantMod.LOGGER.error("[AI Assistant] Failed to load config", e);
        }
    }

    public static void save() {
        JsonObject obj = new JsonObject();
        obj.addProperty("apiKey", apiKey);
        obj.addProperty("_comment", "Встав сюди свій Anthropic API ключ з https://console.anthropic.com/");
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(obj, writer);
        } catch (Exception e) {
            AiAssistantMod.LOGGER.error("[AI Assistant] Failed to save config", e);
        }
    }
}
